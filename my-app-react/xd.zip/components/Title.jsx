import React from "react";

const Title = () =>{
    return(
        <h1>Lista de Usuarios</h1>
    )
}

export default Title