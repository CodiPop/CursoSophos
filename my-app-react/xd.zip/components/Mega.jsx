import React from "react";
import ItemUser from "./ItemUser";
import Title from "./Title";

const  App= () =>{

    return(< React.Fragment><Title/><ItemUser/></React.Fragment>

    )
}

export default App;